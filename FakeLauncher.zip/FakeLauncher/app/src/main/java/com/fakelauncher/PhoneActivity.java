package com.fakelauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Locale;
import java.util.Random;

public class PhoneActivity extends Activity {

    private TextView input;
    private ToneGenerator tone;
    private Handler handler = new Handler();
    private boolean inCall = false;
    private AudioManager am;

    @Override
    protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        // ВАЖНО: голосовой поток
        tone = new ToneGenerator(AudioManager.STREAM_VOICE_CALL, 100);

        showDialer();
    }

    /* ===================== DIALER ===================== */

    private void showDialer() {
        inCall = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(20,20,20,20);
        root.setGravity(Gravity.BOTTOM);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        input = new TextView(this);
        input.setTextSize(36);
        input.setTextColor(Color.WHITE);
        input.setGravity(Gravity.START);
        input.setPadding(10,10,10,10);

        LinearLayout.LayoutParams ip =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        top.addView(input, ip);

        Button del = createRoundedButton("⌫", Color.DKGRAY, Color.WHITE);
        del.setTextSize(28);
        del.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String t = input.getText().toString();
                if (t.length() > 0) input.setText(t.substring(0, t.length() - 1));
            }
        });
        top.addView(del);

        root.addView(top);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setRowCount(4);
        grid.setUseDefaultMargins(true);

        String[] keys = {"1","2","3","4","5","6","7","8","9","*","0","#"};
        for (int i = 0; i < keys.length; i++) {
            final String key = keys[i];
            Button btn = createRoundedButton(key, Color.DKGRAY, Color.WHITE);
            btn.setTextSize(26);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (inCall) return;
                    input.append(key);
                    checkIMEI();
                }
            });

            GridLayout.LayoutParams p = new GridLayout.LayoutParams();
            p.width = 0;
            p.height = GridLayout.LayoutParams.WRAP_CONTENT;
            p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            grid.addView(btn, p);
        }

        root.addView(grid);

        Button call = createRoundedButton("📞", Color.GREEN, Color.WHITE);
        call.setTextSize(32);
        call.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String num = input.getText().toString();
                if (num.length() > 0 && !num.contains("*#06#")) {
                    showCallScreen(num);
                }
            }
        });

        LinearLayout.LayoutParams cp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.topMargin = 20;
        root.addView(call, cp);

        setContentView(root);
    }

    /* ===================== IMEI ===================== */

    private void checkIMEI() {
        String t = input.getText().toString();
        if (t.contains("*#06#")) {

            String imei = generateIMEI();

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("IMEI:");
            builder.setMessage(imei);
            builder.setPositiveButton("OK", null);

            AlertDialog dialog = builder.create();

            if (dialog.getWindow() != null) {
                GradientDrawable bg = new GradientDrawable();
                bg.setColor(Color.WHITE);
                bg.setCornerRadius(40);
                dialog.getWindow().setBackgroundDrawable(bg);
            }

            dialog.show();
            input.setText("");
        }
    }

    /* ===================== CALL SCREEN ===================== */

    private void showCallScreen(String number) {
        inCall = true;

        // ВАЖНО: режим звонка
        am.setMode(AudioManager.MODE_IN_CALL);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setGravity(Gravity.CENTER);
        root.setPadding(40,40,40,40);

        TextView num = new TextView(this);
        num.setText(number);
        num.setTextSize(32);
        num.setTextColor(Color.WHITE);
        num.setGravity(Gravity.CENTER);

        TextView status = new TextView(this);
        String lang = Locale.getDefault().getLanguage();

		if (lang.equals("ru")) {
			status.setText("Вызов…");
		} else {
			status.setText("Calling…");
		}
        status.setTextColor(Color.GRAY);
        status.setPadding(0,20,0,60);

        Button end = createRoundedButton("📞", Color.RED, Color.WHITE);
        end.setTextSize(36);
        end.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                endCall();
            }
        });

        root.addView(num);
        root.addView(status);
        root.addView(end);

        setContentView(root);
        startRinging();
    }

    private void startRinging() {
        handler.post(ringRunnable);
    }

    private Runnable ringRunnable = new Runnable() {
        @Override public void run() {
            if (!inCall) return;
            tone.startTone(ToneGenerator.TONE_SUP_RINGTONE, 2000);
            handler.postDelayed(this, 4000);
        }
    };

    private void endCall() {
        inCall = false;
        handler.removeCallbacks(ringRunnable);
        tone.stopTone();

        // ВОЗВРАТ РЕЖИМА
        am.setMode(AudioManager.MODE_NORMAL);

        showDialer();
    }

    /* ===================== UTILS ===================== */

    private Button createRoundedButton(String text, int bgColor, int textColor) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(textColor);
        btn.setTextSize(22);

        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(25);
        gd.setColor(bgColor);
        btn.setBackground(gd);

        return btn;
    }

    private String generateIMEI() {
        int[] digits = new int[14];
        Random r = new Random();
        for (int i = 0; i < 14; i++) digits[i] = r.nextInt(10);

        int sum = 0;
        for (int i = 0; i < 14; i++) {
            int d = digits[i];
            if (i % 2 == 1) {
                d *= 2;
                if (d > 9) d -= 9;
            }
            sum += d;
        }

        int check = (10 - sum % 10) % 10;

        StringBuilder sb = new StringBuilder();
        for (int d : digits) sb.append(d);
        sb.append(check);
        return sb.toString();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tone != null) tone.release();
    }
}