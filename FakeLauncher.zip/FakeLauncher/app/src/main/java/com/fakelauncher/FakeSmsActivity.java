package com.fakelauncher;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class FakeSmsActivity extends Activity {

    private boolean isRussian;
    private FrameLayout root;
    private boolean isComposeScreen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Locale locale = Locale.getDefault();
        isRussian = locale != null && "ru".equalsIgnoreCase(locale.getLanguage());

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        showMainScreen();
    }

    /* ================= BACK ================= */

    @Override
    public void onBackPressed() {
        if (isComposeScreen) {
            showMainScreen();
        } else {
            super.onBackPressed();
        }
    }

    /* ================= ГЛАВНЫЙ ЭКРАН ================= */

    private void showMainScreen() {
        isComposeScreen = false;
        root.removeAllViews();

        // Текст "нет сообщений"
        TextView emptyText = new TextView(this);
        emptyText.setText(isRussian ? "Нет сообщений" : "No messages");
        emptyText.setTextSize(18);
        emptyText.setTextColor(Color.GRAY);
        emptyText.setGravity(Gravity.CENTER);

        FrameLayout.LayoutParams textParams =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT);
        textParams.gravity = Gravity.CENTER;

        root.addView(emptyText, textParams);

        // Кнопка "+"
        Button plusButton = new Button(this);
        plusButton.setText("+");
        plusButton.setTextSize(32);
        plusButton.setTextColor(Color.WHITE);

        GradientDrawable plusBg = new GradientDrawable();
        plusBg.setShape(GradientDrawable.OVAL);
        plusBg.setColor(Color.parseColor("#4CAF50"));
        plusButton.setBackgroundDrawable(plusBg);

        FrameLayout.LayoutParams plusParams =
                new FrameLayout.LayoutParams(160, 160);
        plusParams.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        plusParams.rightMargin = 32;
        plusParams.bottomMargin = 32;

        plusButton.setLayoutParams(plusParams);

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showComposeScreen();
            }
        });

        root.addView(plusButton);
    }

    /* ================= ЭКРАН СОЗДАНИЯ ================= */

    private void showComposeScreen() {
        isComposeScreen = true;
        root.removeAllViews();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(24, 24, 24, 24);

        /* -------- Получатель -------- */

        final EditText recipientEdit = new EditText(this);
        recipientEdit.setHint(isRussian ? "Получатель" : "Recipient");
        recipientEdit.setSingleLine(true);
        recipientEdit.setTextSize(16);
        recipientEdit.setPadding(24, 24, 24, 24);

        GradientDrawable recipientBg = new GradientDrawable();
        recipientBg.setColor(Color.parseColor("#F1F3F4"));
        recipientBg.setCornerRadius(48);
        recipientEdit.setBackgroundDrawable(recipientBg);

        LinearLayout.LayoutParams recipientParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        recipientParams.bottomMargin = 24;

        /* -------- Сообщение -------- */

        final EditText messageEdit = new EditText(this);
        messageEdit.setHint(isRussian ? "Сообщение" : "Message");
        messageEdit.setTextSize(16);
        messageEdit.setMinLines(5);
        messageEdit.setGravity(Gravity.TOP);
        messageEdit.setPadding(24, 24, 24, 24);

        GradientDrawable messageBg = new GradientDrawable();
        messageBg.setColor(Color.parseColor("#F1F3F4"));
        messageBg.setCornerRadius(32);
        messageEdit.setBackgroundDrawable(messageBg);

        LinearLayout.LayoutParams messageParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        messageParams.bottomMargin = 24;

        /* -------- Самолётик -------- */

        Button sendButton = new Button(this);
        sendButton.setText("➤");
        sendButton.setTextSize(22);
        sendButton.setTextColor(Color.WHITE);

        GradientDrawable sendBg = new GradientDrawable();
        sendBg.setShape(GradientDrawable.OVAL);
        sendBg.setColor(Color.parseColor("#1A73E8"));
        sendButton.setBackgroundDrawable(sendBg);

        LinearLayout.LayoutParams sendParams =
                new LinearLayout.LayoutParams(140, 140);
        sendParams.gravity = Gravity.RIGHT;

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String r = recipientEdit.getText().toString().trim();
                String m = messageEdit.getText().toString().trim();

                if (TextUtils.isEmpty(r) || TextUtils.isEmpty(m)) {
                    Toast.makeText(
                            FakeSmsActivity.this,
                            isRussian ? "Заполните все поля" : "Please fill in all fields",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                if (!isValidPhone(r)) {
                    Toast.makeText(
                            FakeSmsActivity.this,
                            isRussian
                                    ? "Нет такого номера или контакта"
                                    : "No such number or contact",
                            Toast.LENGTH_SHORT
                    ).show();
                    return;
                }

                Toast.makeText(
                        FakeSmsActivity.this,
                        isRussian ? "Отправлено!" : "Sent!",
                        Toast.LENGTH_SHORT
                ).show();

                showMainScreen();
            }
        });

        layout.addView(recipientEdit, recipientParams);
        layout.addView(messageEdit, messageParams);
        layout.addView(sendButton, sendParams);

        root.addView(layout);
    }

    /* ================= ПРОВЕРКА НОМЕРА ================= */

    private boolean isValidPhone(String s) {
        if (TextUtils.isEmpty(s)) return false;

        if (s.startsWith("+")) {
            if (s.length() == 1) return false;
            s = s.substring(1);
        }

        for (int i = 0; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}