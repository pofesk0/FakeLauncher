package com.fakelauncher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.graphics.drawable.GradientDrawable;

import java.util.Locale;

public class LauncherActivity extends Activity {

    @Override
    protected void onResume() {
        super.onResume();

        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        ComponentName adminComponent =
                new ComponentName(this, MyDeviceAdminReceiver.class);

        DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

        if (!dpm.isAdminActive(adminComponent)) {
            Intent intent =
                    new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);

            intent.putExtra(
                    DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    adminComponent
            );

            String explanation = "ru".equalsIgnoreCase(Locale.getDefault().getLanguage())
				? "Это приложение для запуска фейкового главного экрана при вводе неверного пароля на экране блокировки, чтобы злоумышленник думал, что это и есть ваши данные (но там их нет).\nВы можете использовать это приложение когда вас заставляют показать содержимое телефона. В таком случае просто вводите неправильный пароль и приложение покажет 'пустышку'.\nРазрешение администратора требуется для отслеживания неверных попыток ввода пароля."
				: "This is an app for launching a fake home screen after an incorrect lock screen password is entered, so an attacker thinks this is your real data (but there are none).\nYou can use this app when someone is trying to duress you into showing the contents of your phone. In this situation you just enter the wrong password and app show a 'decoy'.\nDevice Administrator permission is required to track incorrect password entry attempts.";

            intent.putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    explanation
            );

            startActivity(intent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.TOP | Gravity.START);
        root.setBackgroundColor(0xFFFFFFFF);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP | Gravity.START);

        TextView globe = createIcon("🌍");
        TextView phone = createIcon("📞");
        TextView sms   = createIcon("💬");

        globe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(
                        new Intent(LauncherActivity.this, BrowserActivity.class)
                );
            }
        });

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(
                        new Intent(LauncherActivity.this, PhoneActivity.class)
                );
            }
        });

        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(
                        new Intent(LauncherActivity.this, FakeSmsActivity.class)
                );
            }
        });

        row.addView(globe);
        row.addView(phone);
        row.addView(sms);

        root.addView(row);
        setContentView(root);
    }

    private TextView createIcon(String emoji) {
        TextView tv = new TextView(this);
        tv.setText(emoji);
        tv.setTextSize(40);
        tv.setGravity(Gravity.CENTER);

        int size = dp(72);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(size, size);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        tv.setLayoutParams(lp);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFEDEDED);
        bg.setStroke(dp(2), 0xFF444444);
        bg.setCornerRadius(0);

        tv.setBackground(bg);

        return tv;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
